package com.tangotab.core.services;

/**
 * This class will be used as base service class for all the service class we have.
 * @author dillip.lenka
 *
 */
public class TangoTabBaseService 
{
	
}
