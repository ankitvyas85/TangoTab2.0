package com.tangotab.core.vo;
/**
 * 
 * @author dillip.lenka
 *
 */
public class TangoTabBaseVo {

}
